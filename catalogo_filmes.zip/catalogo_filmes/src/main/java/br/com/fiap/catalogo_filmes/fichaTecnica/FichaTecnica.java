package br.com.fiap.catalogo_filmes.fichaTecnica;

public record FichaTecnica(
        String direcao,
        String elenco,
        String roteiro,
        String classificacao,
        String producao) {
}