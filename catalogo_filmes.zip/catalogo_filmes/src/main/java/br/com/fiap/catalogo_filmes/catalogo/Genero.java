package br.com.fiap.catalogo_filmes.catalogo;

public enum Genero {
    SUSPENSE,
    COMÉDIA,
    DRAMA,
    DOCUMENTÁRIO,
    AÇÃO,
    FICÇÃO
}