package br.com.fiap.catalogo_filmes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoFilmesApplicationTests {

	@Test
	void contextLoads() {
	}

}
